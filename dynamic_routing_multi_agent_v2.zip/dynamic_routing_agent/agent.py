"""
Dynamic Routing Multi-Agent System
Uses a supervisor LLM to decide which specialist worker handles a query,
then synthesizes the result with a final LLM pass.
"""

import os
import operator
import requests
from functools import lru_cache
from typing import TypedDict, Annotated

from langgraph.graph import StateGraph, END
from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage, SystemMessage
from duckduckgo_search import DDGS


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

class AgentState(TypedDict):
    user_query: str
    route: str
    raw_result: str          # single worker result (replaces list accumulator)
    final_answer: str
    error: str               # surfaces tool/routing errors gracefully


# ---------------------------------------------------------------------------
# LLM (cached — one instance per API key, not one per call)
# ---------------------------------------------------------------------------

@lru_cache(maxsize=4)
def get_llm(api_key: str) -> ChatGroq:
    return ChatGroq(
        groq_api_key=api_key,
        model_name="llama3-70b-8192",
        temperature=0,
    )


def _llm() -> ChatGroq:
    key = os.getenv("GROQ_API_KEY", "")
    if not key:
        raise EnvironmentError("GROQ_API_KEY is not set.")
    return get_llm(key)


# ---------------------------------------------------------------------------
# Tools  (pure functions — no LangGraph state here)
# ---------------------------------------------------------------------------

def web_search_tool(query: str) -> str:
    """Return top-3 DuckDuckGo results for *query*."""
    try:
        results = DDGS().text(query, max_results=3)
        if not results:
            return "No search results found."
        return "\n\n".join(
            f"**{r['title']}**\n{r['body']}" for r in results
        )
    except Exception as exc:
        return f"Search failed: {exc}"


def weather_tool(query: str) -> str:
    """
    Extract a city name from *query* with the LLM, then fetch live weather
    from Open-Meteo (no API key needed).
    """
    # --- extract city name ---
    try:
        city_response = _llm().invoke([
            SystemMessage(content="Extract only the city name from the user's query. "
                                  "Reply with just the city name, nothing else."),
            HumanMessage(content=query),
        ])
        city = city_response.content.strip()
    except Exception as exc:
        return f"Could not extract city name: {exc}"

    # --- geocode ---
    try:
        geo = requests.get(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": city, "count": 1},
            timeout=5,
        ).json()
        if not geo.get("results"):
            return f"Could not find location: '{city}'."
        lat = geo["results"][0]["latitude"]
        lon = geo["results"][0]["longitude"]
        location_name = geo["results"][0].get("name", city)
    except Exception as exc:
        return f"Geocoding failed: {exc}"

    # --- fetch weather ---
    try:
        weather = requests.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": lat,
                "longitude": lon,
                "current_weather": True,
            },
            timeout=5,
        ).json()
        cw = weather["current_weather"]
        return (
            f"Current weather in {location_name}:\n"
            f"  Temperature : {cw['temperature']} °C\n"
            f"  Wind speed  : {cw['windspeed']} km/h\n"
            f"  Wind dir    : {cw['winddirection']}°\n"
            f"  Weather code: {cw['weathercode']}"
        )
    except Exception as exc:
        return f"Weather fetch failed: {exc}"


def wiki_tool(query: str) -> str:
    """
    Derive a Wikipedia article title from *query* with the LLM, then
    return the page summary.
    """
    try:
        title_response = _llm().invoke([
            SystemMessage(content="Extract the main topic or entity as a Wikipedia article title. "
                                  "Reply with just the title, nothing else."),
            HumanMessage(content=query),
        ])
        topic = title_response.content.strip().replace(" ", "_")
    except Exception as exc:
        return f"Could not extract topic: {exc}"

    try:
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{topic}"
        data = requests.get(url, timeout=5).json()
        extract = data.get("extract", "")
        if not extract:
            return f"No Wikipedia article found for '{topic}'."
        return extract
    except Exception as exc:
        return f"Wikipedia lookup failed: {exc}"


# ---------------------------------------------------------------------------
# Graph nodes
# ---------------------------------------------------------------------------

VALID_ROUTES = {"search", "weather", "wiki"}


def supervisor_node(state: AgentState) -> dict:
    """Classify the query and pick a worker route."""
    prompt = (
        "You are a routing supervisor. Classify the user query into exactly one category.\n\n"
        f"Query: {state['user_query']}\n\n"
        "Categories:\n"
        "  search  — current events, news, facts that need a live web search\n"
        "  weather — weather or temperature for a city\n"
        "  wiki    — encyclopaedic background on a topic, person, or place\n\n"
        "Reply with ONLY one word: search, weather, or wiki."
    )
    try:
        response = _llm().invoke([
            SystemMessage(content="You are a routing supervisor. Reply with exactly one word."),
            HumanMessage(content=prompt),
        ])
        route = response.content.strip().lower().split()[0]  # guard extra words
        if route not in VALID_ROUTES:
            route = "search"   # safe fallback
    except Exception as exc:
        return {"route": "search", "error": f"Supervisor failed, defaulting to search: {exc}"}

    return {"route": route, "error": ""}


def search_node(state: AgentState) -> dict:
    return {"raw_result": web_search_tool(state["user_query"])}


def weather_node(state: AgentState) -> dict:
    return {"raw_result": weather_tool(state["user_query"])}


def wiki_node(state: AgentState) -> dict:
    return {"raw_result": wiki_tool(state["user_query"])}


def synthesizer_node(state: AgentState) -> dict:
    """Use the LLM to turn raw tool output into a clean, friendly answer."""
    prompt = (
        f"User question: {state['user_query']}\n\n"
        f"Raw information retrieved ({state['route']} tool):\n{state['raw_result']}\n\n"
        "Write a clear, concise answer to the user's question using the information above. "
        "Do not mention internal tool names or routing details."
    )
    try:
        response = _llm().invoke([
            SystemMessage(content="You are a helpful assistant. Summarise retrieved information "
                                  "into a direct answer for the user."),
            HumanMessage(content=prompt),
        ])
        return {"final_answer": response.content.strip()}
    except Exception as exc:
        # Fallback: return raw result rather than crashing
        return {"final_answer": f"{state['raw_result']}\n\n(Synthesis failed: {exc})"}


def route_selector(state: AgentState) -> str:
    return state["route"]


# ---------------------------------------------------------------------------
# Graph construction (compiled once at module load)
# ---------------------------------------------------------------------------

def _build_graph() -> StateGraph:
    g = StateGraph(AgentState)

    g.add_node("supervisor", supervisor_node)
    g.add_node("search",     search_node)
    g.add_node("weather",    weather_node)
    g.add_node("wiki",       wiki_node)
    g.add_node("synthesizer", synthesizer_node)

    g.set_entry_point("supervisor")

    g.add_conditional_edges(
        "supervisor",
        route_selector,
        {"search": "search", "weather": "weather", "wiki": "wiki"},
    )

    for worker in ("search", "weather", "wiki"):
        g.add_edge(worker, "synthesizer")

    g.add_edge("synthesizer", END)

    return g.compile()


GRAPH = _build_graph()


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_agents(query: str) -> tuple[str, str]:
    """
    Run the agent graph on *query*.

    Returns:
        (final_answer, route_used)
    """
    if not query or not query.strip():
        return "Please enter a question.", "none"

    result = GRAPH.invoke({
        "user_query": query.strip(),
        "route": "",
        "raw_result": "",
        "final_answer": "",
        "error": "",
    })

    return result["final_answer"], result["route"]
