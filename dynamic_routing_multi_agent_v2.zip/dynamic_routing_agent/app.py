"""
Streamlit UI for the Dynamic Routing Multi-Agent System.
"""

import os
import streamlit as st
from agent import run_agents

st.set_page_config(
    page_title="Dynamic Routing Multi-Agent",
    page_icon="🤖",
    layout="centered",
)

st.title("🤖 Dynamic Routing Multi-Agent")
st.caption("Automatically routes your query to the best tool: web search, weather, or Wikipedia.")

# --- Sidebar: API key ---
with st.sidebar:
    st.header("Configuration")
    groq_key = st.text_input("Groq API Key", type="password", placeholder="gsk_...")
    if groq_key:
        os.environ["GROQ_API_KEY"] = groq_key
        st.success("API key set ✓")

    st.markdown("---")
    st.markdown("**How it works**")
    st.markdown(
        "1. A supervisor LLM reads your query\n"
        "2. It routes to the best worker:\n"
        "   - 🔍 **Search** — live web results\n"
        "   - 🌤 **Weather** — current conditions\n"
        "   - 📖 **Wiki** — encyclopaedic background\n"
        "3. A synthesizer LLM writes a clean answer"
    )

# --- Main area ---
query = st.text_input(
    "Ask anything",
    placeholder="e.g. What's the weather in Tokyo? / Who is Nikola Tesla?",
)

run_button = st.button("Run", type="primary", use_container_width=True)

if run_button:
    if not groq_key:
        st.warning("⚠️ Please enter your Groq API key in the sidebar first.")
    elif not query.strip():
        st.warning("⚠️ Please enter a question.")
    else:
        with st.spinner("Thinking…"):
            answer, route = run_agents(query)

        # Show which route was chosen
        route_labels = {
            "search":  "🔍 Web Search",
            "weather": "🌤 Weather",
            "wiki":    "📖 Wikipedia",
        }
        st.info(f"Routed to: **{route_labels.get(route, route)}**")
        st.markdown("### Answer")
        st.write(answer)
