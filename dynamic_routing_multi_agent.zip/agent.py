
import os
import requests
import operator
from typing import TypedDict, Annotated

from langgraph.graph import StateGraph, END
from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage, SystemMessage
from duckduckgo_search import DDGS


class AgentState(TypedDict):
    user_query: str
    route: str
    outputs: Annotated[list, operator.add]
    final_answer: str


def get_llm():
    return ChatGroq(
        groq_api_key=os.getenv("GROQ_API_KEY"),
        model_name="llama3-70b-8192",
        temperature=0
    )


def web_search_tool(query):
    results = DDGS().text(query, max_results=3)
    return "\n".join([r["title"] + ": " + r["body"] for r in results])


def weather_tool(city):
    geo = requests.get(
        f"https://geocoding-api.open-meteo.com/v1/search?name={city}&count=1"
    ).json()
    lat = geo["results"][0]["latitude"]
    lon = geo["results"][0]["longitude"]

    weather = requests.get(
        f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"
    ).json()

    return str(weather["current_weather"])


def wiki_tool(topic):
    url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{topic}"
    return requests.get(url).json().get("extract", "No data found.")


def supervisor_agent(state):
    llm = get_llm()

    prompt = f'''
Decide best route for this query:

Query: {state["user_query"]}

Available Workers:
- search
- weather
- wiki

Reply ONLY one word:
search / weather / wiki
'''

    response = llm.invoke([
        SystemMessage(content="You are a routing supervisor."),
        HumanMessage(content=prompt)
    ])

    return {"route": response.content.strip().lower()}


def search_worker(state):
    return {"outputs": [f"SEARCH RESULT:\n{web_search_tool(state['user_query'])}"]}


def weather_worker(state):
    return {"outputs": [f"WEATHER RESULT:\n{weather_tool(state['user_query'])}"]}


def wiki_worker(state):
    return {"outputs": [f"WIKI RESULT:\n{wiki_tool(state['user_query'])}"]}


def synthesizer(state):
    return {"final_answer": "\n\n".join(state["outputs"])}


def dynamic_router(state):
    return state["route"]


def build_graph():
    g = StateGraph(AgentState)

    g.add_node("supervisor", supervisor_agent)
    g.add_node("search", search_worker)
    g.add_node("weather", weather_worker)
    g.add_node("wiki", wiki_worker)
    g.add_node("synthesizer", synthesizer)

    g.set_entry_point("supervisor")

    g.add_conditional_edges(
        "supervisor",
        dynamic_router,
        {
            "search": "search",
            "weather": "weather",
            "wiki": "wiki"
        }
    )

    g.add_edge("search", "synthesizer")
    g.add_edge("weather", "synthesizer")
    g.add_edge("wiki", "synthesizer")
    g.add_edge("synthesizer", END)

    return g.compile()


GRAPH = build_graph()


def run_agents(query):
    result = GRAPH.invoke({
        "user_query": query,
        "route": "",
        "outputs": [],
        "final_answer": ""
    })

    return result["final_answer"]
