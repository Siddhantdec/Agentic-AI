
import streamlit as st
import os
from agent import run_agents

st.set_page_config(page_title="Dynamic Routing Multi Agent")

st.title("Dynamic Routing Multi-Agentic System")

groq_key = st.sidebar.text_input("Enter Groq API Key", type="password")

if groq_key:
    os.environ["GROQ_API_KEY"] = groq_key

query = st.text_input("Ask your question")

if st.button("Run Agents"):
    if not groq_key:
        st.warning("Please enter Groq API Key")
    else:
        result = run_agents(query)
        st.success(result)
