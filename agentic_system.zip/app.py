"""
app.py — Streamlit UI for the LangGraph Agentic System
"""

import streamlit as st
import os

# ─────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────

st.set_page_config(
    page_title="AI Research Agent",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────
# CUSTOM CSS
# ─────────────────────────────────────────

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Syne:wght@400;700;800&display=swap');

:root {
    --bg: #0d0f14;
    --surface: #151820;
    --surface2: #1c2030;
    --accent: #5b8cff;
    --accent2: #ff6b6b;
    --accent3: #43e97b;
    --text: #e8ecf4;
    --muted: #6b7a99;
    --border: #252d40;
}

html, body, .stApp {
    background-color: var(--bg) !important;
    color: var(--text) !important;
    font-family: 'Syne', sans-serif !important;
}

section[data-testid="stSidebar"] {
    background: var(--surface) !important;
    border-right: 1px solid var(--border) !important;
}

section[data-testid="stSidebar"] * {
    color: var(--text) !important;
}

.agent-header {
    text-align: center;
    padding: 2rem 0 1rem 0;
}

.agent-header h1 {
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: 2.6rem;
    background: linear-gradient(135deg, #5b8cff, #43e97b, #ff6b6b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin: 0;
    letter-spacing: -1px;
}

.agent-header p {
    color: var(--muted);
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.85rem;
    margin-top: 0.4rem;
}

.chat-user {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 12px 12px 4px 12px;
    padding: 1rem 1.2rem;
    margin: 0.7rem 0;
    margin-left: 10%;
}

.chat-assistant {
    background: var(--surface);
    border: 1px solid #5b8cff22;
    border-left: 3px solid var(--accent);
    border-radius: 4px 12px 12px 12px;
    padding: 1rem 1.2rem;
    margin: 0.7rem 0;
    margin-right: 5%;
}

.chat-label {
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.7rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 0.5rem;
    opacity: 0.6;
}

.user-label { color: var(--accent2); }
.assistant-label { color: var(--accent); }

.tools-used {
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.7rem;
    color: var(--muted);
    margin-top: 0.6rem;
    padding-top: 0.5rem;
    border-top: 1px solid var(--border);
}

.stTextInput > div > div > input {
    background: var(--surface) !important;
    border: 1px solid var(--border) !important;
    border-radius: 8px !important;
    color: var(--text) !important;
    font-family: 'Syne', sans-serif !important;
}

.stTextInput > div > div > input:focus {
    border-color: var(--accent) !important;
    box-shadow: 0 0 0 2px rgba(91,140,255,0.15) !important;
}

.stButton > button {
    background: linear-gradient(135deg, #5b8cff, #43e97b) !important;
    color: #0d0f14 !important;
    font-family: 'Syne', sans-serif !important;
    font-weight: 700 !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 0.5rem 1.5rem !important;
}

.tool-card {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 0.9rem 1rem;
    margin-bottom: 0.7rem;
}

.tool-card-title {
    font-family: 'JetBrains Mono', monospace;
    font-weight: 600;
    font-size: 0.85rem;
    margin-bottom: 0.3rem;
}

.tool-card-desc {
    font-size: 0.78rem;
    color: var(--muted);
    line-height: 1.4;
}

.metric-card {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 0.8rem;
    text-align: center;
    margin-bottom: 0.5rem;
}

hr { border-color: var(--border) !important; }
#MainMenu, footer, header { visibility: hidden; }
.block-container { padding-top: 1rem !important; }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────
# SESSION STATE INIT
# ─────────────────────────────────────────

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "tools_log" not in st.session_state:
    st.session_state.tools_log = []
if "total_queries" not in st.session_state:
    st.session_state.total_queries = 0
if "tool_counts" not in st.session_state:
    st.session_state.tool_counts = {"web_search": 0, "get_weather": 0, "wikipedia_summary": 0}


# ─────────────────────────────────────────
# IMPORT AGENT
# ─────────────────────────────────────────

@st.cache_resource
def load_agent():
    try:
        from agent import run_agent
        return run_agent
    except Exception as e:
        return None

run_agent = load_agent()


# ─────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────

with st.sidebar:
    st.markdown("""
    <div style='text-align:center; padding: 1rem 0 0.5rem 0;'>
        <div style='font-size: 1.5rem;'>🤖</div>
        <div style='font-family: Syne, sans-serif; font-weight: 800; font-size: 1.1rem; color: #5b8cff;'>Agent Tools</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class='tool-card'>
        <div class='tool-card-title' style='color:#5b8cff;'>🔍 web_search</div>
        <div class='tool-card-desc'>DuckDuckGo — current events, news, general facts</div>
    </div>
    <div class='tool-card'>
        <div class='tool-card-title' style='color:#43e97b;'>🌤️ get_weather</div>
        <div class='tool-card-desc'>Real-time weather via Open-Meteo. Any city, no key needed.</div>
    </div>
    <div class='tool-card'>
        <div class='tool-card-title' style='color:#ff6b6b;'>📖 wikipedia_summary</div>
        <div class='tool-card-desc'>Wikipedia summaries — people, places, events, concepts</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("<div style='font-family: JetBrains Mono, monospace; font-size: 0.78rem; color: #6b7a99; text-transform: uppercase; letter-spacing: 0.5px;'>Configuration</div>", unsafe_allow_html=True)

    openai_key = st.text_input("OpenAI API Key", type="password", placeholder="sk-...", help="Required to run the agent")
    if openai_key:
        os.environ["OPENAI_API_KEY"] = openai_key

    weatherstack_key = st.text_input("Weatherstack API Key (optional)", type="password", placeholder="Leave blank for Open-Meteo")
    if weatherstack_key:
        os.environ["WEATHERSTACK_API_KEY"] = weatherstack_key

    st.markdown("---")
    st.markdown("<div style='font-family: JetBrains Mono, monospace; font-size: 0.78rem; color: #6b7a99; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 0.5rem;'>Session Stats</div>", unsafe_allow_html=True)

    tc = st.session_state.tool_counts
    st.markdown(f"""
    <div class='metric-card'>
        <div style='font-family:Syne,sans-serif;font-weight:800;font-size:1.6rem;color:#5b8cff;'>{st.session_state.total_queries}</div>
        <div style='font-family:JetBrains Mono,monospace;font-size:0.68rem;color:#6b7a99;text-transform:uppercase;'>Total Queries</div>
    </div>
    <div style='display:flex; gap:0.5rem;'>
        <div class='metric-card' style='flex:1'>
            <div style='font-family:Syne,sans-serif;font-weight:800;font-size:1.2rem;color:#5b8cff;'>{tc['web_search']}</div>
            <div style='font-family:JetBrains Mono,monospace;font-size:0.65rem;color:#6b7a99;text-transform:uppercase;'>Web</div>
        </div>
        <div class='metric-card' style='flex:1'>
            <div style='font-family:Syne,sans-serif;font-weight:800;font-size:1.2rem;color:#43e97b;'>{tc['get_weather']}</div>
            <div style='font-family:JetBrains Mono,monospace;font-size:0.65rem;color:#6b7a99;text-transform:uppercase;'>Weather</div>
        </div>
        <div class='metric-card' style='flex:1'>
            <div style='font-family:Syne,sans-serif;font-weight:800;font-size:1.2rem;color:#ff6b6b;'>{tc['wikipedia_summary']}</div>
            <div style='font-family:JetBrains Mono,monospace;font-size:0.65rem;color:#6b7a99;text-transform:uppercase;'>Wiki</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.chat_history = []
        st.session_state.tools_log = []
        st.session_state.total_queries = 0
        st.session_state.tool_counts = {"web_search": 0, "get_weather": 0, "wikipedia_summary": 0}
        st.rerun()


# ─────────────────────────────────────────
# MAIN AREA
# ─────────────────────────────────────────

st.markdown("""
<div class='agent-header'>
    <h1>AI Research Agent</h1>
    <p>⚡ Powered by LangGraph · GPT-3.5 · DuckDuckGo · Weather · Wikipedia</p>
</div>
""", unsafe_allow_html=True)

# Example prompts
if not st.session_state.chat_history:
    st.markdown("<div style='text-align:center; color:#6b7a99; font-size:0.85rem; margin-bottom:0.5rem; font-family: JetBrains Mono, monospace;'>Try asking...</div>", unsafe_allow_html=True)
    col1, col2, col3, col4 = st.columns(4)
    examples = ["🌤️ Weather in Tokyo", "🔍 Latest AI news", "📖 Who is Elon Musk?", "🔍 Python vs JavaScript"]
    prompts = [
        "What is the current weather in Tokyo?",
        "What are the latest developments in AI in 2024?",
        "Who is Elon Musk? Give me a summary.",
        "Search for the differences between Python and JavaScript in 2024",
    ]
    for col, ex, prompt in zip([col1, col2, col3, col4], examples, prompts):
        with col:
            if st.button(ex, use_container_width=True, key=f"ex_{ex}"):
                st.session_state["prefill"] = prompt
                st.rerun()

# Chat display
TOOL_COLORS = {
    "web_search": ("#5b8cff", "🔍", "Web Search"),
    "get_weather": ("#43e97b", "🌤️", "Weather"),
    "wikipedia_summary": ("#ff6b6b", "📖", "Wikipedia"),
}

for i, turn in enumerate(st.session_state.chat_history):
    if turn["role"] == "user":
        st.markdown(f"""
        <div class='chat-user'>
            <div class='chat-label user-label'>You</div>
            {turn['content']}
        </div>
        """, unsafe_allow_html=True)
    else:
        tools_used = st.session_state.tools_log[i // 2] if i // 2 < len(st.session_state.tools_log) else []
        badge_html = ""
        for t in tools_used:
            color, icon, label = TOOL_COLORS.get(t, ("#888", "🔧", t))
            badge_html += f"<span style='background:{color}22;color:{color};border:1px solid {color}44;display:inline-block;padding:2px 9px;border-radius:12px;font-size:0.7rem;font-family:JetBrains Mono,monospace;font-weight:600;margin:2px;'>{icon} {label}</span>"
        tools_section = f"<div class='tools-used'>Tools used: {badge_html}</div>" if tools_used else ""
        st.markdown(f"""
        <div class='chat-assistant'>
            <div class='chat-label assistant-label'>Agent</div>
            {turn['content']}
            {tools_section}
        </div>
        """, unsafe_allow_html=True)

# Input
st.markdown("<br>", unsafe_allow_html=True)
prefill = st.session_state.pop("prefill", "")

col_input, col_btn = st.columns([5, 1])
with col_input:
    user_input = st.text_input(
        "Message",
        value=prefill,
        placeholder="Ask anything — weather, news, who/what/why...",
        label_visibility="collapsed",
        key="user_input_box"
    )
with col_btn:
    send = st.button("Send →", use_container_width=True)

# Handle send
if send and user_input.strip():
    if not run_agent:
        st.error("❌ Failed to load agent. Make sure agent.py is in the same folder and packages are installed.")
    elif not os.environ.get("OPENAI_API_KEY"):
        st.warning("⚠️ Please enter your OpenAI API key in the sidebar.")
    else:
        with st.spinner("🤖 Agent is thinking..."):
            try:
                response, updated_history, tools_used = run_agent(
                    user_input.strip(),
                    st.session_state.chat_history
                )
                st.session_state.chat_history = updated_history
                st.session_state.tools_log.append(tools_used)
                st.session_state.total_queries += 1
                for t in tools_used:
                    if t in st.session_state.tool_counts:
                        st.session_state.tool_counts[t] += 1
                st.rerun()
            except Exception as e:
                st.error(f"Agent error: {str(e)}")
