"""
agent.py — LangGraph Agentic System
Tools: DuckDuckGo Search, Weather (Open-Meteo/Weatherstack), Wikipedia
"""

import os
import json
import requests
from dotenv import load_dotenv
from typing import Annotated, TypedDict

from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage, SystemMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from duckduckgo_search import DDGS

load_dotenv()


# ─────────────────────────────────────────
# STATE
# ─────────────────────────────────────────

class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]


# ─────────────────────────────────────────
# TOOL 1 — DuckDuckGo Web Search
# ─────────────────────────────────────────

@tool
def web_search(query: str) -> str:
    """Search the web using DuckDuckGo. Use this for general knowledge, news, current events, or any factual question."""
    try:
        results = DDGS().text(query, max_results=4)
        if not results:
            return "No results found."
        output = []
        for r in results:
            output.append(f"**{r['title']}**\n{r['body']}\n🔗 {r['href']}")
        return "\n\n".join(output)
    except Exception as e:
        return f"Search error: {str(e)}"


# ─────────────────────────────────────────
# TOOL 2 — Weather (Open-Meteo + geocoding, no key needed; Weatherstack if key set)
# ─────────────────────────────────────────

@tool
def get_weather(city: str) -> str:
    """Get current weather for any city. Input should be a city name like 'London' or 'New Delhi'."""
    api_key = os.getenv("WEATHERSTACK_API_KEY", "")
    if api_key:
        try:
            url = f"http://api.weatherstack.com/current?access_key={api_key}&query={city}"
            resp = requests.get(url, timeout=8)
            data = resp.json()
            if "current" in data:
                cur = data["current"]
                loc = data.get("location", {})
                return (
                    f"🌍 **{loc.get('name', city)}, {loc.get('country', '')}**\n"
                    f"🌡️ Temperature: {cur['temperature']}°C (Feels like {cur['feelslike']}°C)\n"
                    f"☁️ Condition: {', '.join(cur.get('weather_descriptions', ['N/A']))}\n"
                    f"💧 Humidity: {cur['humidity']}%\n"
                    f"💨 Wind: {cur['wind_speed']} km/h {cur['wind_dir']}\n"
                    f"👁️ Visibility: {cur['visibility']} km"
                )
        except Exception:
            pass

    # Fallback: Open-Meteo (no API key needed)
    try:
        geo = requests.get(
            f"https://geocoding-api.open-meteo.com/v1/search?name={city}&count=1",
            timeout=6
        ).json()
        results = geo.get("results", [])
        if not results:
            return f"Could not find weather data for '{city}'."
        r = results[0]
        lat, lon, name, country = r["latitude"], r["longitude"], r["name"], r.get("country", "")
        weather = requests.get(
            f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
            f"&current_weather=true&hourly=relative_humidity_2m,apparent_temperature",
            timeout=6
        ).json()
        cw = weather.get("current_weather", {})
        wcode_map = {
            0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
            45: "Fog", 48: "Icy fog", 51: "Light drizzle", 53: "Drizzle", 55: "Heavy drizzle",
            61: "Light rain", 63: "Rain", 65: "Heavy rain", 71: "Light snow", 73: "Snow",
            75: "Heavy snow", 80: "Rain showers", 81: "Heavy showers", 95: "Thunderstorm"
        }
        condition = wcode_map.get(cw.get("weathercode", 0), "Unknown")
        return (
            f"🌍 **{name}, {country}**\n"
            f"🌡️ Temperature: {cw.get('temperature', 'N/A')}°C\n"
            f"☁️ Condition: {condition}\n"
            f"💨 Wind: {cw.get('windspeed', 'N/A')} km/h\n"
            f"*(Source: Open-Meteo — free, no key required)*"
        )
    except Exception as e:
        return f"Weather fetch failed: {str(e)}"


# ─────────────────────────────────────────
# TOOL 3 — Wikipedia Summary
# ─────────────────────────────────────────

@tool
def wikipedia_summary(topic: str) -> str:
    """Get a Wikipedia summary for any topic, person, place, concept, or historical event."""
    try:
        url = "https://en.wikipedia.org/api/rest_v1/page/summary/" + topic.replace(" ", "_")
        resp = requests.get(url, timeout=8, headers={"User-Agent": "AgentBot/1.0"})
        if resp.status_code != 200:
            search = requests.get(
                f"https://en.wikipedia.org/w/api.php?action=opensearch&search={topic}&limit=1&format=json",
                timeout=6
            ).json()
            if search[1]:
                url = "https://en.wikipedia.org/api/rest_v1/page/summary/" + search[1][0].replace(" ", "_")
                resp = requests.get(url, timeout=8, headers={"User-Agent": "AgentBot/1.0"})
        data = resp.json()
        title = data.get("title", topic)
        extract = data.get("extract", "No summary available.")
        page_url = data.get("content_urls", {}).get("desktop", {}).get("page", "")
        result = f"📖 **{title}**\n\n{extract}"
        if page_url:
            result += f"\n\n🔗 {page_url}"
        return result
    except Exception as e:
        return f"Wikipedia error: {str(e)}"


# ─────────────────────────────────────────
# TOOL REGISTRY
# ─────────────────────────────────────────

TOOLS = [web_search, get_weather, wikipedia_summary]
TOOL_MAP = {t.name: t for t in TOOLS}


# ─────────────────────────────────────────
# LLM
# ─────────────────────────────────────────

def get_llm():
    return ChatOpenAI(
        model="gpt-3.5-turbo",
        temperature=0,
    ).bind_tools(TOOLS)


# ─────────────────────────────────────────
# GRAPH NODES
# ─────────────────────────────────────────

def agent_node(state: AgentState) -> AgentState:
    llm = get_llm()
    response = llm.invoke(state["messages"])
    return {"messages": [response]}


def tool_node(state: AgentState) -> AgentState:
    last_message = state["messages"][-1]
    tool_results = []
    for tool_call in last_message.tool_calls:
        tool_fn = TOOL_MAP.get(tool_call["name"])
        if tool_fn:
            result = tool_fn.invoke(tool_call["args"])
        else:
            result = f"Tool '{tool_call['name']}' not found."
        tool_results.append(
            ToolMessage(content=str(result), tool_call_id=tool_call["id"])
        )
    return {"messages": tool_results}


def should_continue(state: AgentState) -> str:
    last = state["messages"][-1]
    if hasattr(last, "tool_calls") and last.tool_calls:
        return "tools"
    return END


# ─────────────────────────────────────────
# BUILD GRAPH
# ─────────────────────────────────────────

def build_graph():
    graph = StateGraph(AgentState)
    graph.add_node("agent", agent_node)
    graph.add_node("tools", tool_node)
    graph.set_entry_point("agent")
    graph.add_conditional_edges("agent", should_continue, {"tools": "tools", END: END})
    graph.add_edge("tools", "agent")
    return graph.compile()


AGENT = build_graph()


# ─────────────────────────────────────────
# SYSTEM PROMPT
# ─────────────────────────────────────────

SYSTEM_PROMPT = """You are a smart AI research assistant with three powerful tools:

1. **web_search** — search the web with DuckDuckGo for current news, facts, or any general information
2. **get_weather** — get real-time weather for any city in the world
3. **wikipedia_summary** — get structured Wikipedia summaries for topics, people, places, events

Guidelines:
- Always choose the most appropriate tool(s) for the query
- For weather questions → use get_weather
- For "who is / what is / history of" → use wikipedia_summary
- For recent news or current events → use web_search
- You can use multiple tools in sequence if needed
- Respond in a clear, helpful, and well-formatted markdown style
"""


# ─────────────────────────────────────────
# PUBLIC INTERFACE
# ─────────────────────────────────────────

def run_agent(user_message: str, chat_history: list[dict]) -> tuple[str, list[dict], list[str]]:
    """
    Run the agent.
    Returns: (final_response, updated_history, tools_used)
    """
    messages = [SystemMessage(content=SYSTEM_PROMPT)]
    for turn in chat_history:
        if turn["role"] == "user":
            messages.append(HumanMessage(content=turn["content"]))
        else:
            messages.append(AIMessage(content=turn["content"]))
    messages.append(HumanMessage(content=user_message))

    result = AGENT.invoke({"messages": messages})

    # Collect which tools were used
    tools_used = []
    for msg in result["messages"]:
        if hasattr(msg, "tool_calls") and msg.tool_calls:
            for tc in msg.tool_calls:
                if tc["name"] not in tools_used:
                    tools_used.append(tc["name"])

    final = result["messages"][-1].content
    updated_history = chat_history + [
        {"role": "user", "content": user_message},
        {"role": "assistant", "content": final},
    ]
    return final, updated_history, tools_used
