# AI Research Agent — Agentic System

A LangGraph-powered agentic chatbot with a Streamlit UI, using 3 built-in tools.

## Tools

| Tool | Source | API Key? |
|---|---|---|
| `web_search` | DuckDuckGo (DDGS) | No |
| `get_weather` | Open-Meteo (free) / Weatherstack (optional) | No |
| `wikipedia_summary` | Wikipedia REST API | No |

## Setup & Run

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the app
streamlit run app.py
```

Then enter your **OpenAI API key** in the sidebar. Weather and search work with zero setup.

## Architecture

```
User Input → Streamlit UI (app.py)
               → LangGraph Agent (agent.py)
                   → web_search (DuckDuckGo)
                   → get_weather (Open-Meteo)
                   → wikipedia_summary (Wikipedia)
               → GPT-3.5 synthesizes answer
             → Display in Streamlit
```

## Files

- `agent.py` — LangGraph graph, tool definitions, ReAct loop
- `app.py` — Streamlit dark-themed UI
- `requirements.txt` — all dependencies
