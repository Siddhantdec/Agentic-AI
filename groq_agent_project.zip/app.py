"""
app.py — Streamlit UI using GROQ
"""

import streamlit as st
import os
from agent import run_agent


st.set_page_config(page_title="Groq AI Agent")

st.title("🚀 Groq AI Research Agent")

groq_key = st.sidebar.text_input(
    "Enter GROQ API Key",
    type="password"
)

if groq_key:
    os.environ["GROQ_API_KEY"] = groq_key


if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

if "tools_log" not in st.session_state:
    st.session_state.tools_log = []


user_input = st.text_input("Ask Anything")

if st.button("Send"):

    if not groq_key:
        st.warning("Please enter Groq API Key")

    else:

        response, updated_history, tools_used = run_agent(
            user_input,
            st.session_state.chat_history
        )

        st.session_state.chat_history = updated_history
        st.session_state.tools_log.append(tools_used)


for msg in st.session_state.chat_history:

    if msg["role"] == "user":
        st.markdown(f"**You:** {msg['content']}")

    else:
        st.markdown(f"**Assistant:** {msg['content']}")
