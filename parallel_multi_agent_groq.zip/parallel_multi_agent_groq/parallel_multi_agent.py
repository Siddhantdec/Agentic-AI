"""
╔══════════════════════════════════════════════════════════════════════════════╗
║        PARALLEL MULTI-AGENT SYSTEM — LangGraph + Groq                      ║
║                                                                              ║
║  4 Agents | 4 Tools | 2 run in PARALLEL                                     ║
║                                                                              ║
║  Graph:                                                                      ║
║    📥 Input Agent (sequential)                                               ║
║         │  fan-out                                                           ║
║    ┌────┴────┐                                                               ║
║    ▼         ▼   ← PARALLEL                                                  ║
║  🔍 Search  🌤️ Weather                                                       ║
║    └────┬────┘                                                               ║
║         │  fan-in                                                            ║
║    🧠 Synthesiser Agent (sequential)                                         ║
║         │                                                                    ║
║        END                                                                   ║
║                                                                              ║
║  Tools (1 per agent):                                                        ║
║   Agent 1 → LLM Query Parser                                                ║
║   Agent 2 → DuckDuckGo Web Search                                           ║
║   Agent 3 → Open-Meteo Weather API (free, no key)                           ║
║   Agent 4 → Wikipedia REST API + LLM synthesis                              ║
║                                                                              ║
║  Model: Groq llama-3.3-70b-versatile                                        ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import operator
import requests
from typing import TypedDict, Annotated, Optional
from dotenv import load_dotenv

from langchain_groq import ChatGroq
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.graph import StateGraph, END
from duckduckgo_search import DDGS

load_dotenv()


# ══════════════════════════════════════════════════════════════════════════════
# SHARED STATE
# ══════════════════════════════════════════════════════════════════════════════

class AgentState(TypedDict):
    user_query:       str
    parsed_topic:     Optional[str]
    parsed_city:      Optional[str]
    # Annotated[list, operator.add] lets BOTH parallel agents append safely
    parallel_outputs: Annotated[list[str], operator.add]
    final_answer:     Optional[str]
    logs:             Annotated[list[str], operator.add]


# ══════════════════════════════════════════════════════════════════════════════
# LLM
# ══════════════════════════════════════════════════════════════════════════════

def get_llm(temperature: float = 0.3) -> ChatGroq:
    return ChatGroq(model="llama-3.3-70b-versatile", temperature=temperature, max_tokens=1024)


# ══════════════════════════════════════════════════════════════════════════════
# TOOLS
# ══════════════════════════════════════════════════════════════════════════════

def tool_parse_query(raw_query: str) -> dict:
    """Tool 1 (Agent 1) — LLM extracts topic & city from the raw query."""
    llm = get_llm(temperature=0)
    prompt = f"""Extract two things from this user query:
1. The main topic or subject (for web search and Wikipedia)
2. Any city name mentioned (for weather — leave NONE if not present)

User query: "{raw_query}"

Respond in EXACTLY this format:
TOPIC: <the main topic>
CITY: <city name or NONE>"""

    response = llm.invoke([
        SystemMessage(content="You extract structured data from user queries. Follow the format exactly."),
        HumanMessage(content=prompt)
    ])
    topic, city = raw_query, "Mumbai"
    for line in response.content.strip().split("\n"):
        if line.startswith("TOPIC:"):
            topic = line.replace("TOPIC:", "").strip()
        elif line.startswith("CITY:"):
            val = line.replace("CITY:", "").strip()
            if val and val.upper() != "NONE":
                city = val
    return {"topic": topic, "city": city}


def tool_web_search(query: str, max_results: int = 5) -> str:
    """Tool 2 (Agent 2) — DuckDuckGo search, no API key needed."""
    try:
        results = DDGS().text(query, max_results=max_results)
        if not results:
            return f"No results found for: {query}"
        parts = []
        for i, r in enumerate(results, 1):
            parts.append(f"[{i}] {r['title']}\n{r['body']}\n{r['href']}")
        return "\n\n".join(parts)
    except Exception as e:
        return f"Search error: {str(e)}"


def tool_get_weather(city: str) -> str:
    """Tool 3 (Agent 3) — Open-Meteo real-time weather, no API key needed."""
    WMO = {
        0:"☀️ Clear",1:"🌤️ Mainly clear",2:"⛅ Partly cloudy",3:"☁️ Overcast",
        45:"🌫️ Fog",51:"🌦️ Light drizzle",61:"🌧️ Light rain",63:"🌧️ Rain",
        65:"🌧️ Heavy rain",71:"❄️ Light snow",73:"❄️ Snow",80:"🌦️ Showers",
        95:"⛈️ Thunderstorm"
    }
    try:
        geo = requests.get(
            f"https://geocoding-api.open-meteo.com/v1/search?name={city}&count=1", timeout=6
        ).json().get("results", [])
        if not geo:
            return f"❌ City not found: {city}"
        r = geo[0]
        lat, lon, name, country = r["latitude"], r["longitude"], r.get("name", city), r.get("country", "")
        wx = requests.get(
            f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
            f"&current_weather=true&hourly=relative_humidity_2m,apparent_temperature,precipitation_probability",
            timeout=6
        ).json()
        cw = wx.get("current_weather", {})
        h  = wx.get("hourly", {})
        return (
            f"📍 {name}, {country}\n"
            f"🌡️ Temp: {cw.get('temperature','N/A')}°C (feels like {h.get('apparent_temperature',[None])[0]}°C)\n"
            f"{WMO.get(cw.get('weathercode',0),'Unknown')}\n"
            f"💧 Humidity: {h.get('relative_humidity_2m',[None])[0]}%  "
            f"🌧️ Rain: {h.get('precipitation_probability',[None])[0]}%\n"
            f"💨 Wind: {cw.get('windspeed','N/A')} km/h"
        )
    except Exception as e:
        return f"❌ Weather error for {city}: {str(e)}"


def tool_wikipedia(topic: str) -> str:
    """Tool 4 (Agent 4) — Wikipedia REST API, no API key needed."""
    try:
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{topic.replace(' ','_')}"
        resp = requests.get(url, timeout=8, headers={"User-Agent": "MultiAgentBot/1.0"})
        if resp.status_code != 200:
            srch = requests.get(
                f"https://en.wikipedia.org/w/api.php?action=opensearch&search={topic}&limit=1&format=json",
                timeout=6
            ).json()
            if srch[1]:
                url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{srch[1][0].replace(' ','_')}"
                resp = requests.get(url, timeout=8, headers={"User-Agent": "MultiAgentBot/1.0"})
        data = resp.json()
        title = data.get("title", topic)
        extract = data.get("extract", "No summary found.")
        page_url = data.get("content_urls", {}).get("desktop", {}).get("page", "")
        result = f"📖 {title}\n\n{extract}"
        if page_url:
            result += f"\n\n🔗 {page_url}"
        return result
    except Exception as e:
        return f"❌ Wikipedia error: {str(e)}"


# ══════════════════════════════════════════════════════════════════════════════
# AGENT 1 — INPUT AGENT (Sequential)
# ══════════════════════════════════════════════════════════════════════════════

def input_agent(state: AgentState) -> AgentState:
    """
    Agent 1 — Sequential. Runs first.
    Tool: LLM Query Parser
    Extracts topic and city from raw user query.
    Both values are then consumed by the 2 parallel agents.
    """
    print("\n📥 [Agent 1 — Input Agent] Running...")
    parsed = tool_parse_query(state["user_query"])
    print(f"   ✓ Topic: '{parsed['topic']}' | City: '{parsed['city']}'")
    return {
        **state,
        "parsed_topic": parsed["topic"],
        "parsed_city":  parsed["city"],
        "logs": [f"✅ Input Agent: Topic='{parsed['topic']}' | City='{parsed['city']}'"],
    }


# ══════════════════════════════════════════════════════════════════════════════
# AGENT 2 — SEARCH AGENT (Parallel)
# ══════════════════════════════════════════════════════════════════════════════

def search_agent(state: AgentState) -> AgentState:
    """
    Agent 2 — PARALLEL with Agent 3.
    Tool: DuckDuckGo Web Search
    Searches the web for the parsed topic, summarises with LLM.
    Appends result to parallel_outputs (safe with operator.add).
    """
    print("\n🔍 [Agent 2 — Search Agent] Running (PARALLEL)...")
    topic = state.get("parsed_topic") or state["user_query"]
    raw = tool_web_search(f"{topic} latest 2026", max_results=5)

    llm = get_llm(temperature=0.2)
    prompt = f"""Summarise these DuckDuckGo search results for "{topic}" in 4-6 bullet points.
Be specific and factual.

RESULTS:
{raw}

Label your response: 🔍 WEB SEARCH RESULTS"""

    summary = llm.invoke([
        SystemMessage(content="You are a concise research summariser."),
        HumanMessage(content=prompt)
    ]).content
    print(f"   ✓ Search done ({len(summary)} chars)")

    return {
        **state,
        "parallel_outputs": [f"[SEARCH AGENT OUTPUT]\n{summary}"],
        "logs": [f"✅ Search Agent: Web search complete for '{topic}'."],
    }


# ══════════════════════════════════════════════════════════════════════════════
# AGENT 3 — WEATHER AGENT (Parallel)
# ══════════════════════════════════════════════════════════════════════════════

def weather_agent(state: AgentState) -> AgentState:
    """
    Agent 3 — PARALLEL with Agent 2.
    Tool: Open-Meteo Weather API (free, no key)
    Fetches real-time weather for the parsed city.
    Appends result to parallel_outputs (safe with operator.add).
    """
    print("\n🌤️  [Agent 3 — Weather Agent] Running (PARALLEL)...")
    city = state.get("parsed_city") or "Mumbai"
    weather = tool_get_weather(city)
    print(f"   ✓ Weather fetched for '{city}'")

    return {
        **state,
        "parallel_outputs": [f"[WEATHER AGENT OUTPUT]\n🌤️ LIVE WEATHER — {city.upper()}\n\n{weather}"],
        "logs": [f"✅ Weather Agent: Live weather fetched for '{city}'."],
    }


# ══════════════════════════════════════════════════════════════════════════════
# AGENT 4 — SYNTHESISER AGENT (Sequential — fan-in)
# ══════════════════════════════════════════════════════════════════════════════

def synthesiser_agent(state: AgentState) -> AgentState:
    """
    Agent 4 — Sequential. Runs AFTER both parallel agents finish (fan-in).
    Tool: Wikipedia REST API
    Fetches Wikipedia context, then merges all 3 data sources into one answer.
    """
    print("\n🧠 [Agent 4 — Synthesiser] Running (fan-in)...")
    topic = state.get("parsed_topic") or state["user_query"]

    wiki = tool_wikipedia(topic)
    print(f"   ✓ Wikipedia fetched for '{topic}'")

    parallel = state.get("parallel_outputs", [])
    search_out  = next((p for p in parallel if "SEARCH AGENT"  in p), "Search data unavailable.")
    weather_out = next((p for p in parallel if "WEATHER AGENT" in p), "Weather data unavailable.")
    print(f"   ✓ Received {len(parallel)} parallel outputs")

    llm = get_llm(temperature=0.4)
    prompt = f"""Combine the three sources below into one comprehensive response for: "{state['user_query']}"

📖 WIKIPEDIA:
{wiki}

{search_out}

{weather_out}

Write a response with these sections:
1. **Overview** — background from Wikipedia
2. **Latest Updates** — key points from web search
3. **Weather Context** — current weather info
4. **Summary** — 2-3 sentence conclusion

Use markdown. Be clear and informative."""

    final_answer = llm.invoke([
        SystemMessage(content="You are a skilled synthesiser who merges multiple data sources."),
        HumanMessage(content=prompt)
    ]).content
    print(f"   ✓ Final answer ready ({len(final_answer)} chars)")

    return {
        **state,
        "final_answer": final_answer,
        "logs": [f"✅ Synthesiser: Wikipedia + all parallel outputs merged."],
    }


# ══════════════════════════════════════════════════════════════════════════════
# BUILD GRAPH
# ══════════════════════════════════════════════════════════════════════════════

def build_graph():
    """
    Graph topology:
      input_agent
         │  fan-out (2 edges from same source)
         ├──→ search_agent   ─┐
         └──→ weather_agent  ─┤  fan-in (2 edges to same target)
                               ▼
                       synthesiser_agent → END
    """
    g = StateGraph(AgentState)
    g.add_node("input",       input_agent)
    g.add_node("search",      search_agent)
    g.add_node("weather",     weather_agent)
    g.add_node("synthesiser", synthesiser_agent)

    g.set_entry_point("input")
    g.add_edge("input",   "search")       # fan-out ──┐
    g.add_edge("input",   "weather")      # fan-out ──┘ both run in parallel
    g.add_edge("search",  "synthesiser")  # fan-in  ──┐
    g.add_edge("weather", "synthesiser")  # fan-in  ──┘ wait for both
    g.add_edge("synthesiser", END)

    return g.compile()


GRAPH = build_graph()


def run_agents(user_query: str) -> dict:
    print(f"\n{'═'*55}\n  🚀 PARALLEL MULTI-AGENT — Query: {user_query}\n{'═'*55}")
    result = GRAPH.invoke({
        "user_query": user_query,
        "parsed_topic": None, "parsed_city": None,
        "parallel_outputs": [], "final_answer": None, "logs": [],
    })
    print(f"\n{'═'*55}\n  ✅ ALL 4 AGENTS COMPLETE\n{'═'*55}")
    return result


# ══════════════════════════════════════════════════════════════════════════════
# STREAMLIT UI
# ══════════════════════════════════════════════════════════════════════════════

def run_app():
    import streamlit as st

    st.set_page_config(page_title="Parallel Multi-Agent", page_icon="⚡", layout="wide")

    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Fira+Code:wght@400;500&family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
    :root {
        --bg:#060810; --surf:#0c0f1a; --surf2:#121828; --border:#1a2235;
        --seq:#6366f1; --par1:#f59e0b; --par2:#10b981; --syn:#e879f9;
        --text:#e2e8f0; --muted:#4b5675;
    }
    html,body,.stApp { background:var(--bg)!important; color:var(--text)!important; font-family:'Plus Jakarta Sans',sans-serif!important; }
    section[data-testid="stSidebar"] { background:var(--surf)!important; border-right:1px solid var(--border)!important; }
    section[data-testid="stSidebar"] * { color:var(--text)!important; }
    .hero { text-align:center; padding:1.8rem 0 0.5rem; }
    .hero h1 { font-family:'Plus Jakarta Sans',sans-serif; font-weight:800; font-size:2.4rem; margin:0;
        background:linear-gradient(135deg,#6366f1,#f59e0b,#10b981,#e879f9);
        -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
    .hero p { font-family:'Fira Code',monospace; font-size:0.78rem; color:var(--muted); margin-top:0.3rem; }
    .ag-card { background:var(--surf2); border:1px solid var(--border); border-radius:10px; padding:0.8rem; margin-bottom:0.5rem; }
    .log-line { font-family:'Fira Code',monospace; font-size:0.7rem; color:#10b981; padding:0.25rem 0; border-bottom:1px solid var(--border); }
    .stButton>button { background:linear-gradient(135deg,#6366f1,#e879f9)!important; color:#060810!important;
        font-family:'Plus Jakarta Sans',sans-serif!important; font-weight:800!important; font-size:1rem!important;
        border:none!important; border-radius:10px!important; width:100%!important; padding:0.65rem!important; }
    .stTextInput>div>div>input { background:var(--surf2)!important; border:1px solid var(--border)!important;
        border-radius:8px!important; color:var(--text)!important; }
    #MainMenu,footer,header { visibility:hidden; }
    .block-container { padding-top:0.5rem!important; }
    </style>
    """, unsafe_allow_html=True)

    # Sidebar
    with st.sidebar:
        st.markdown("<div style='text-align:center;padding:1rem 0;'><div style='font-size:2rem;'>⚡</div><div style='font-family:Plus Jakarta Sans,sans-serif;font-weight:800;font-size:1rem;color:#6366f1;'>Parallel Multi-Agent</div><div style='font-family:Fira Code,monospace;font-size:0.7rem;color:#4b5675;'>llama-3.3-70b-versatile</div></div>", unsafe_allow_html=True)
        groq_key = st.text_input("🔑 Groq API Key", type="password", placeholder="gsk_...")
        if groq_key:
            os.environ["GROQ_API_KEY"] = groq_key
        st.markdown("---")
        for var, icon, title, tool, mode, desc in [
            ("--seq",  "📥", "Input Agent",      "LLM Query Parser", "sequential", "Parses topic & city"),
            ("--par1", "🔍", "Search Agent",      "DuckDuckGo",       "parallel",   "Web search for topic"),
            ("--par2", "🌤️","Weather Agent",      "Open-Meteo API",   "parallel",   "Real-time weather"),
            ("--syn",  "🧠", "Synthesiser Agent", "Wikipedia API",    "sequential", "Merges all outputs"),
        ]:
            bc = "#f59e0b" if mode=="parallel" else "#6366f1"
            st.markdown(f"<div class='ag-card' style='border-left:3px solid var({var});'><div style='font-family:Fira Code,monospace;font-size:0.82rem;color:var({var});margin-bottom:0.2rem;'>{icon} {title} <span style='background:{bc}11;color:{bc};border:1px solid {bc}44;padding:1px 7px;border-radius:10px;font-size:0.62rem;'>{mode}</span></div><div style='font-family:Fira Code,monospace;font-size:0.68rem;color:#6366f1;'>🔧 {tool}</div><div style='font-size:0.76rem;color:#4b5675;'>{desc}</div></div>", unsafe_allow_html=True)
        st.markdown("<div style='font-family:Fira Code,monospace;font-size:0.7rem;color:#6366f1;margin-top:0.5rem;'>Free key: console.groq.com</div>", unsafe_allow_html=True)

    # Main
    st.markdown("<div class='hero'><h1>Parallel Multi-Agent System</h1><p>⚡ LangGraph Fan-out/Fan-in · Groq llama-3.3-70b · 4 Agents · 4 Tools</p></div>", unsafe_allow_html=True)

    # Diagram
    st.markdown("""
    <div style='display:flex;flex-direction:column;align-items:center;margin:1rem 0;gap:0;'>
        <div style='padding:0.5rem 1.2rem;border-radius:8px;border:1px solid #6366f1;color:#6366f1;font-family:Fira Code,monospace;font-size:0.75rem;background:#6366f111;'>📥 Input Agent | 🔧 LLM Parser</div>
        <div style='color:#4b5675;padding:0.15rem;'>▼ fan-out</div>
        <div style='display:flex;gap:1.5rem;align-items:center;'>
            <div style='padding:0.5rem 1rem;border-radius:8px;border:1px solid #f59e0b;color:#f59e0b;font-family:Fira Code,monospace;font-size:0.72rem;background:#f59e0b11;text-align:center;'>🔍 Search Agent<br><span style='font-size:0.6rem;color:#4b5675;'>🔧 DuckDuckGo</span></div>
            <div style='color:#4b5675;font-size:1.4rem;'>⚡</div>
            <div style='padding:0.5rem 1rem;border-radius:8px;border:1px solid #10b981;color:#10b981;font-family:Fira Code,monospace;font-size:0.72rem;background:#10b98111;text-align:center;'>🌤️ Weather Agent<br><span style='font-size:0.6rem;color:#4b5675;'>🔧 Open-Meteo</span></div>
        </div>
        <div style='color:#4b5675;padding:0.15rem;'>▼ fan-in</div>
        <div style='padding:0.5rem 1.2rem;border-radius:8px;border:1px solid #e879f9;color:#e879f9;font-family:Fira Code,monospace;font-size:0.75rem;background:#e879f911;'>🧠 Synthesiser Agent | 🔧 Wikipedia API</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")

    # Examples
    examples = [
        "Tell me about AI, weather in Bangalore",
        "What is IPL? Weather in Mumbai",
        "Quantum Computing, weather in London",
        "Eiffel Tower, weather in Paris",
        "SpaceX news, weather in New York",
    ]
    cols = st.columns(len(examples))
    for col, ex in zip(cols, examples):
        with col:
            if st.button(ex[:22]+"...", key=f"ex_{ex[:8]}", use_container_width=True):
                st.session_state["prefill"] = ex

    prefill = st.session_state.pop("prefill", "")
    user_query = st.text_input("Query", value=prefill,
        placeholder="Ask anything + include a city (e.g. 'Tell me about AI, weather in Hyderabad')",
        label_visibility="collapsed")

    if st.button("⚡ Run Parallel Multi-Agent System", use_container_width=True):
        if not os.environ.get("GROQ_API_KEY"):
            st.warning("⚠️ Enter your Groq API key in the sidebar.")
        elif not user_query.strip():
            st.warning("⚠️ Please enter a query.")
        else:
            with st.status("⚡ Running...", expanded=True) as status:
                st.write("📥 Agent 1 — Input: Parsing query...")
                st.write("🔍 Agent 2 & 🌤️ Agent 3: Running IN PARALLEL...")
                st.write("🧠 Agent 4 — Synthesiser: Merging all outputs...")
                try:
                    result = run_agents(user_query.strip())
                    status.update(label="✅ All Agents Complete!", state="complete", expanded=False)

                    c1, c2 = st.columns(2)
                    with c1: st.markdown(f"<div style='background:#6366f111;border:1px solid #6366f144;border-radius:8px;padding:0.65rem;font-family:Fira Code,monospace;font-size:0.8rem;color:#6366f1;'>🔎 Topic: <b>{result.get('parsed_topic','')}</b></div>", unsafe_allow_html=True)
                    with c2: st.markdown(f"<div style='background:#10b98111;border:1px solid #10b98144;border-radius:8px;padding:0.65rem;font-family:Fira Code,monospace;font-size:0.8rem;color:#10b981;'>🌍 City: <b>{result.get('parsed_city','')}</b></div>", unsafe_allow_html=True)

                    st.markdown("<br>", unsafe_allow_html=True)
                    st.markdown("### 📋 Execution Log")
                    log_html = "".join([f"<div class='log-line'>{l}</div>" for l in result.get("logs",[])])
                    st.markdown(f"<div style='background:#0c0f1a;border:1px solid #1a2235;border-radius:10px;padding:0.8rem;'>{log_html}</div>", unsafe_allow_html=True)

                    st.markdown("<br>", unsafe_allow_html=True)
                    t1, t2, t3 = st.tabs(["🧠 Final Answer", "🔍 Search Output", "🌤️ Weather Output"])
                    with t1: st.markdown(result.get("final_answer",""))
                    with t2:
                        p = result.get("parallel_outputs",[])
                        st.text_area("", value=next((x for x in p if "SEARCH" in x),"N/A"), height=350, label_visibility="collapsed")
                    with t3:
                        p = result.get("parallel_outputs",[])
                        st.text_area("", value=next((x for x in p if "WEATHER" in x),"N/A"), height=250, label_visibility="collapsed")
                except Exception as e:
                    status.update(label="❌ Failed", state="error")
                    st.error(f"Error: {str(e)}")


if __name__ == "__main__":
    run_app()
