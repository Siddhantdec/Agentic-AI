"""
╔══════════════════════════════════════════════════════════════════════════════╗
║           DAILY BRIEFING CREW — crew.py                                    ║
║                                                                              ║
║  Defines the CrewAI Crew, Agents, Tasks, and Tools.                         ║
║  - LLM     : Groq (llama-3.3-70b-versatile) via langchain-groq              ║
║  - Tools   : DuckDuckGoSearchRun, custom OpenMeteo weather tool             ║
║  - Process : Sequential (IPL → AI News → Weather → Movies → Supervisor)    ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import requests
from textwrap import dedent

from crewai import Agent, Task, Crew, Process
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import tool

from langchain_groq import ChatGroq
from langchain_community.tools import DuckDuckGoSearchRun


# ══════════════════════════════════════════════════════════════════════════════
# LLM — Groq (shared across all agents)
# ══════════════════════════════════════════════════════════════════════════════

def get_groq_llm():
    """
    Returns a ChatGroq LLM instance.

    Model: llama-3.3-70b-versatile
      - Free tier available at console.groq.com
      - Excellent at instruction following, summarisation, and writing
      - Very fast inference (ideal for multi-agent pipelines)

    Requires: GROQ_API_KEY environment variable (set in .env)
    """
    return ChatGroq(
        model="llama-3.3-70b-versatile",
        temperature=0.3,      # Low temp = consistent, factual output
        max_tokens=2048,       # Enough room for detailed reports
    )


# ══════════════════════════════════════════════════════════════════════════════
# CUSTOM TOOLS
# ══════════════════════════════════════════════════════════════════════════════

@tool("Weather Fetcher Tool")
def weather_fetcher_tool(cities: str) -> str:
    """
    Fetches real-time weather data for a comma-separated list of cities
    using the Open-Meteo API (free, no API key required).

    Args:
        cities: Comma-separated city names e.g. "Mumbai,Delhi,London"

    Returns:
        Formatted weather report string for all cities.

    APIs used:
        - Open-Meteo Geocoding: https://geocoding-api.open-meteo.com
        - Open-Meteo Forecast:  https://api.open-meteo.com
    """
    # WMO weather code → human-readable description mapping
    WMO_CODES = {
        0:  "☀️ Clear sky",
        1:  "🌤️ Mainly clear",
        2:  "⛅ Partly cloudy",
        3:  "☁️ Overcast",
        45: "🌫️ Fog",
        48: "🌫️ Icy fog",
        51: "🌦️ Light drizzle",
        53: "🌦️ Drizzle",
        55: "🌧️ Heavy drizzle",
        61: "🌧️ Light rain",
        63: "🌧️ Moderate rain",
        65: "🌧️ Heavy rain",
        71: "❄️ Light snow",
        73: "❄️ Snow",
        75: "❄️ Heavy snow",
        80: "🌦️ Rain showers",
        81: "🌧️ Heavy showers",
        95: "⛈️ Thunderstorm",
        96: "⛈️ Thunderstorm with hail",
    }

    city_list = [c.strip() for c in cities.split(",") if c.strip()]
    cards = []

    for city in city_list:
        try:
            # Step 1: Geocoding — get lat/lon
            geo = requests.get(
                f"https://geocoding-api.open-meteo.com/v1/search?name={city}&count=1",
                timeout=8
            ).json()

            results = geo.get("results", [])
            if not results:
                cards.append(f"❌ {city}: Location not found.")
                continue

            r      = results[0]
            lat    = r["latitude"]
            lon    = r["longitude"]
            name   = r.get("name", city)
            country = r.get("country", "")

            # Step 2: Fetch forecast (current weather + hourly details)
            wx = requests.get(
                f"https://api.open-meteo.com/v1/forecast"
                f"?latitude={lat}&longitude={lon}"
                f"&current_weather=true"
                f"&hourly=relative_humidity_2m,apparent_temperature,precipitation_probability",
                timeout=8
            ).json()

            cw         = wx.get("current_weather", {})
            temp       = cw.get("temperature", "N/A")
            windspeed  = cw.get("windspeed", "N/A")
            wcode      = cw.get("weathercode", 0)
            condition  = WMO_CODES.get(wcode, "Unknown")

            hourly     = wx.get("hourly", {})
            humidity   = hourly.get("relative_humidity_2m",    [None])[0]
            feels_like = hourly.get("apparent_temperature",    [None])[0]
            rain_prob  = hourly.get("precipitation_probability",[None])[0]

            # Build tip
            if rain_prob and rain_prob > 60:
                tip = "☂️ Tip: Carry an umbrella today!"
            elif temp and temp > 35:
                tip = "🥤 Tip: Stay hydrated — it's hot out there!"
            elif temp and temp < 10:
                tip = "🧥 Tip: Bundle up — it's quite cold today!"
            else:
                tip = "😊 Tip: Comfortable weather — enjoy your day!"

            card = (
                f"📍 **{name}, {country}**\n"
                f"   {condition}\n"
                f"   🌡️  Temperature : {temp}°C  (Feels like {feels_like}°C)\n"
                f"   💧 Humidity    : {humidity}%\n"
                f"   🌧️  Rain chance : {rain_prob}%\n"
                f"   💨 Wind speed  : {windspeed} km/h\n"
                f"   {tip}"
            )
            cards.append(card)

        except requests.Timeout:
            cards.append(f"❌ {city}: Request timed out.")
        except Exception as e:
            cards.append(f"❌ {city}: Error — {str(e)}")

    return "\n\n" + ("\n\n" + "─" * 40 + "\n\n").join(cards)


# Instantiate DuckDuckGo search tool (shared by IPL, AI news, Movies agents)
duckduckgo_tool = DuckDuckGoSearchRun()


# ══════════════════════════════════════════════════════════════════════════════
# CREW CLASS
# ══════════════════════════════════════════════════════════════════════════════

@CrewBase
class DailyBriefingCrew:
    """
    DailyBriefingCrew
    ══════════════════
    A sequential multi-agent CrewAI system that assembles a personalised
    daily briefing covering:
      1. IPL 2026 cricket news
      2. AI & tech world news
      3. Live weather for selected cities
      4. Movie listings for a chosen city
      5. Final polished newsletter (compiled by Supervisor)

    Process: Sequential — each agent completes its task before the next begins.

    Config files:
      - config/agents.yaml  → Agent roles, goals, backstories
      - config/tasks.yaml   → Task descriptions and expected outputs
    """

    agents_config = "config/agents.yaml"
    tasks_config  = "config/tasks.yaml"

    # ── Private helper ──────────────────────────────────────────────────────

    def _llm(self):
        """Shared Groq LLM instance for all agents."""
        return get_groq_llm()

    # ── AGENTS ──────────────────────────────────────────────────────────────

    @agent
    def ipl_news_agent(self) -> Agent:
        """
        IPL News Agent
        ───────────────
        Tool   : DuckDuckGoSearchRun
        Purpose: Searches for and summarises the latest IPL 2026 cricket news.
        """
        return Agent(
            config=self.agents_config["ipl_news_agent"],
            tools=[duckduckgo_tool],
            llm=self._llm(),
            verbose=True,
            allow_delegation=False,   # Sequential flow — no delegation
            max_iter=3,               # Retry up to 3 times if output is poor
        )

    @agent
    def ai_news_agent(self) -> Agent:
        """
        AI News Agent
        ──────────────
        Tool   : DuckDuckGoSearchRun
        Purpose: Searches for and summarises the latest AI world developments.
        """
        return Agent(
            config=self.agents_config["ai_news_agent"],
            tools=[duckduckgo_tool],
            llm=self._llm(),
            verbose=True,
            allow_delegation=False,
            max_iter=3,
        )

    @agent
    def weather_agent(self) -> Agent:
        """
        Weather Agent
        ──────────────
        Tool   : weather_fetcher_tool (custom Open-Meteo tool)
        Purpose: Fetches and formats real-time weather for specified cities.
        """
        return Agent(
            config=self.agents_config["weather_agent"],
            tools=[weather_fetcher_tool],
            llm=self._llm(),
            verbose=True,
            allow_delegation=False,
            max_iter=2,
        )

    @agent
    def movies_agent(self) -> Agent:
        """
        Movies Agent
        ─────────────
        Tool   : DuckDuckGoSearchRun
        Purpose: Finds and formats current movie listings for the chosen city.
        """
        return Agent(
            config=self.agents_config["movies_agent"],
            tools=[duckduckgo_tool],
            llm=self._llm(),
            verbose=True,
            allow_delegation=False,
            max_iter=3,
        )

    @agent
    def supervisor_agent(self) -> Agent:
        """
        Supervisor / Chief Editor Agent
        ─────────────────────────────────
        Tool   : None (pure LLM reasoning + context from prior tasks)
        Purpose: Compiles all four agent outputs into one polished newsletter.
        """
        return Agent(
            config=self.agents_config["supervisor_agent"],
            tools=[],             # Supervisor only needs the LLM — no search needed
            llm=self._llm(),
            verbose=True,
            allow_delegation=False,
            max_iter=2,
        )

    # ── TASKS ───────────────────────────────────────────────────────────────

    @task
    def fetch_ipl_news(self) -> Task:
        """Task 1 — IPL News: Search and summarise IPL 2026 news."""
        return Task(
            config=self.tasks_config["fetch_ipl_news"],
            agent=self.ipl_news_agent(),
        )

    @task
    def fetch_ai_news(self) -> Task:
        """Task 2 — AI News: Search and summarise AI world developments."""
        return Task(
            config=self.tasks_config["fetch_ai_news"],
            agent=self.ai_news_agent(),
        )

    @task
    def fetch_weather(self) -> Task:
        """Task 3 — Weather: Fetch live weather for specified cities."""
        return Task(
            config=self.tasks_config["fetch_weather"],
            agent=self.weather_agent(),
        )

    @task
    def fetch_movies(self) -> Task:
        """Task 4 — Movies: Find current movie listings for chosen city."""
        return Task(
            config=self.tasks_config["fetch_movies"],
            agent=self.movies_agent(),
        )

    @task
    def compile_briefing(self) -> Task:
        """
        Task 5 — Compile Briefing: Supervisor assembles the final newsletter.

        This task receives context from all four prior tasks automatically
        (as defined in tasks.yaml under the 'context' key).
        """
        return Task(
            config=self.tasks_config["compile_briefing"],
            agent=self.supervisor_agent(),
            context=[
                self.fetch_ipl_news(),
                self.fetch_ai_news(),
                self.fetch_weather(),
                self.fetch_movies(),
            ],
            output_file="output/daily_briefing.md",   # Auto-saves result to file
        )

    # ── CREW ────────────────────────────────────────────────────────────────

    @crew
    def crew(self) -> Crew:
        """
        Assembles and returns the full CrewAI Crew.

        Process.SEQUENTIAL ensures agents run one at a time in order:
          ipl_news_agent → ai_news_agent → weather_agent
          → movies_agent → supervisor_agent

        memory=True enables CrewAI's short-term memory so agents can
        reference earlier outputs during the run.
        """
        return Crew(
            agents=self.agents,    # Auto-populated from @agent decorators
            tasks=self.tasks,      # Auto-populated from @task decorators
            process=Process.SEQUENTIAL,
            memory=False,          # Set True if you want persistent memory
            verbose=True,
            output_log_file="output/crew_run.log",
        )
