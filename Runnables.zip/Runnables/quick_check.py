import langchain
print(langchain.__version__)

import pydantic
print(pydantic.__version__)