import os
os.environ["OPENAI_API_KEY"] = "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"

from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableSequence, RunnableLambda
from langchain_core.output_parsers import StrOutputParser

# Load modern OpenAI model
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.7)

# Create a Prompt Template
prompt = PromptTemplate(
    input_variables=["topic"],
    template="Suggest a catchy blog title about {topic}."
)

# Parser
parser = StrOutputParser()

# Wrap prompt into a lambda using .format()
prompt_step = RunnableLambda(lambda x: prompt.format(**x))

# Sequential chain
chain = RunnableSequence(
    prompt_step,
    llm,
    parser
)

# Run the chain
topic = input("Enter a topic: ")
result = chain.invoke({"topic": topic})

print("Generated Blog Title:", result)

