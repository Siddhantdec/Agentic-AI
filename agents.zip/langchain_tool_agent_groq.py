# ============================================================
# Tool-Using Agent — ReAct Style + Memory (FAISS)
# ============================================================
# Install:
#   pip install groq ddgs python-dotenv faiss-cpu sentence-transformers
#
# Setup:
#   Create a .env file with:  GROQ_API_KEY=gsk_xxxxxxxxxxxx
#
# Memory Design:
#   SHORT-TERM : Last N messages kept in `chat_history` list
#                Passed directly into every LLM call as context
#   LONG-TERM  : All Q&A pairs embedded and stored in FAISS
#                On each new question, top-K similar past memories
#                are retrieved and injected into the system prompt
# ============================================================

import os
import re
import json
import time
import numpy as np
from dotenv import load_dotenv
from groq import Groq
from ddgs import DDGS

# ── Long-term memory deps ──
from sentence_transformers import SentenceTransformer
import faiss

load_dotenv()

# ═══════════════════════════════════════════════════════════
# 1. EMBEDDING MODEL (for long-term FAISS memory)
# ═══════════════════════════════════════════════════════════

print("⏳ Loading embedding model...")
EMBEDDER = SentenceTransformer("all-MiniLM-L6-v2")   # fast, 384-dim embeddings
EMBED_DIM = 384
print("✅ Embedding model ready.\n")

# ═══════════════════════════════════════════════════════════
# 2. FAISS LONG-TERM MEMORY STORE
# ═══════════════════════════════════════════════════════════

class LongTermMemory:
    """
    Stores past Q&A pairs as vector embeddings in a FAISS index.
    On query, retrieves the most semantically similar past memories.
    """

    def __init__(self, dim: int = EMBED_DIM, top_k: int = 3):
        self.index    = faiss.IndexFlatL2(dim)   # L2 distance index
        self.memories = []                        # raw text store
        self.top_k    = top_k

    def add(self, question: str, answer: str):
        """Embed and store a Q&A pair."""
        text      = f"Q: {question}\nA: {answer}"
        embedding = EMBEDDER.encode([text], convert_to_numpy=True).astype("float32")
        self.index.add(embedding)
        self.memories.append(text)
        print(f"  💾 Stored to long-term memory (total: {len(self.memories)})")

    def retrieve(self, query: str) -> list[str]:
        """Retrieve top-K most relevant past memories for a query."""
        if self.index.ntotal == 0:
            return []
        embedding = EMBEDDER.encode([query], convert_to_numpy=True).astype("float32")
        k         = min(self.top_k, self.index.ntotal)
        distances, indices = self.index.search(embedding, k)
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx != -1:
                results.append((float(dist), self.memories[idx]))
        # Sort by distance (lower = more similar)
        results.sort(key=lambda x: x[0])
        return [text for _, text in results]

    def save(self, path: str = "memory.faiss", meta_path: str = "memory.json"):
        """Persist index and raw memories to disk."""
        faiss.write_index(self.index, path)
        with open(meta_path, "w") as f:
            json.dump(self.memories, f, indent=2)
        print(f"  💾 Long-term memory saved → {path}")

    def load(self, path: str = "memory.faiss", meta_path: str = "memory.json"):
        """Load index and raw memories from disk."""
        if os.path.exists(path) and os.path.exists(meta_path):
            self.index = faiss.read_index(path)
            with open(meta_path) as f:
                self.memories = json.load(f)
            print(f"  📂 Long-term memory loaded ({len(self.memories)} memories)")
        else:
            print("  ℹ️  No saved memory found. Starting fresh.")


# ═══════════════════════════════════════════════════════════
# 3. SHORT-TERM MEMORY (sliding window)
# ═══════════════════════════════════════════════════════════

class ShortTermMemory:
    """
    Keeps the last `max_turns` conversation turns in a list.
    Each turn = one user message + one assistant message.
    Passed directly as message history to the LLM.
    """

    def __init__(self, max_turns: int = 5):
        self.max_turns = max_turns
        self.history: list[dict] = []

    def add(self, user_msg: str, assistant_msg: str):
        self.history.append({"role": "user",      "content": user_msg})
        self.history.append({"role": "assistant", "content": assistant_msg})
        # Keep only last max_turns turns (2 messages per turn)
        if len(self.history) > self.max_turns * 2:
            self.history = self.history[-(self.max_turns * 2):]

    def get(self) -> list[dict]:
        return self.history

    def clear(self):
        self.history = []


# ═══════════════════════════════════════════════════════════
# 4. TOOL FUNCTIONS
# ═══════════════════════════════════════════════════════════

def web_search(query: str) -> str:
    """Search the web using DuckDuckGo."""
    try:
        with DDGS() as ddgs:
            results = ddgs.text(query, max_results=3)
            if not results:
                return "No results found."
            output = ""
            for r in results:
                output += f"Title: {r['title']}\nSnippet: {r['body']}\nURL: {r['href']}\n\n"
            return output.strip()
    except Exception as e:
        return f"Search failed: {e}"


def calculator(expression: str) -> str:
    """Evaluate a Python math expression safely."""
    try:
        result = eval(expression, {"__builtins__": {}}, {})
        return str(result)
    except Exception as e:
        return f"Error: {e}"


TOOL_FUNCTIONS = {
    "web_search": web_search,
    "calculator": calculator,
}

# ═══════════════════════════════════════════════════════════
# 5. GROQ CLIENT
# ═══════════════════════════════════════════════════════════

client = Groq(api_key=os.getenv("GROQ_API_KEY"))
MODEL  = "llama-3.3-70b-versatile"

# ═══════════════════════════════════════════════════════════
# 6. SYSTEM PROMPT BUILDER
# ═══════════════════════════════════════════════════════════

BASE_SYSTEM_PROMPT = """You are a helpful research assistant with memory. You can use tools by responding in this exact format:

To use a tool, respond with ONLY this JSON (nothing else):
{"action": "web_search", "input": "your search query here"}
{"action": "calculator", "input": "1.4e9 / 1.3e6"}

To give a final answer after using tools, respond with ONLY this JSON:
{"action": "final_answer", "input": "your complete answer here"}

Available tools:
- web_search: Search the internet for current facts, news, population data, etc.
- calculator: Evaluate math expressions like '1.4e9 / 1.3e6'

Rules:
- Always use web_search for current real-world information.
- Always use calculator for math.
- Output ONLY valid JSON. No extra text, no markdown, no explanation outside the JSON.
- After getting tool results, give a final_answer.
- Use the relevant past memories provided to give context-aware answers.
"""

def build_system_prompt(relevant_memories: list[str]) -> str:
    """Inject relevant long-term memories into the system prompt."""
    if not relevant_memories:
        return BASE_SYSTEM_PROMPT
    memory_block = "\n\n--- Relevant Past Memories ---\n"
    for i, mem in enumerate(relevant_memories, 1):
        memory_block += f"\n[Memory {i}]\n{mem}\n"
    memory_block += "\n--- End of Memories ---\n"
    return BASE_SYSTEM_PROMPT + memory_block

# ═══════════════════════════════════════════════════════════
# 7. JSON PARSER
# ═══════════════════════════════════════════════════════════

def parse_action(text: str) -> dict:
    """Extract JSON action from model response."""
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except Exception:
            pass
    match = re.search(r"\{.*?\}", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0))
        except Exception:
            pass
    return {"action": "final_answer", "input": text}

# ═══════════════════════════════════════════════════════════
# 8. MAIN AGENT FUNCTION
# ═══════════════════════════════════════════════════════════

def ask(
    question: str,
    short_term: ShortTermMemory,
    long_term:  LongTermMemory,
) -> str:
    """
    ReAct agent loop with dual memory:
      1. Retrieve relevant long-term memories → inject into system prompt
      2. Include short-term chat history → pass to LLM
      3. Run ReAct loop (Think → Act → Observe → Answer)
      4. Save Q&A to both memory stores
    """

    print(f"\n{'═'*60}")
    print(f"  Question: {question}")
    print(f"{'═'*60}")

    # ── Step A: Retrieve long-term memories ──
    relevant_memories = long_term.retrieve(question)
    if relevant_memories:
        print(f"\n  🧠 Retrieved {len(relevant_memories)} long-term memories:")
        for m in relevant_memories:
            print(f"     • {m[:80]}...")

    # ── Step B: Build messages ──
    system_prompt = build_system_prompt(relevant_memories)
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(short_term.get())               # short-term window
    messages.append({"role": "user", "content": question})

    print(f"\n> Entering ReAct agent loop...")
    print("─" * 60)

    max_steps = 8
    final_answer = None

    for step in range(1, max_steps + 1):

        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            max_tokens=512,
            temperature=0,
        )

        raw          = response.choices[0].message.content.strip()
        action       = parse_action(raw)
        action_name  = action.get("action", "final_answer")
        action_input = action.get("input", raw)

        # ── Final answer ──
        if action_name == "final_answer":
            print("\n" + "─" * 60)
            print("> Finished chain.")
            final_answer = action_input
            break

        # ── Tool call ──
        if action_name in TOOL_FUNCTIONS:
            print(f"\nStep {step}:")
            print(f"  🛠  Tool      : {action_name}")
            print(f"  📥 Input      : {action_input}")

            result  = TOOL_FUNCTIONS[action_name](action_input)
            display = str(result)[:300] + ("..." if len(str(result)) > 300 else "")
            print(f"  📤 Observation: {display}")

            messages.append({"role": "assistant", "content": raw})
            messages.append({
                "role": "user",
                "content": (
                    f"Observation from {action_name}:\n{result}\n\n"
                    "Now continue. If you have enough information, give a final_answer."
                )
            })
        else:
            final_answer = action_input
            break

    if final_answer is None:
        final_answer = "Max steps reached without a final answer."

    # ── Step C: Save to memory ──
    print(f"\n  💾 Saving to memory stores...")
    short_term.add(question, final_answer)          # short-term: sliding window
    long_term.add(question, final_answer)            # long-term: FAISS vector store
    long_term.save()                                 # persist to disk

    return final_answer

# ═══════════════════════════════════════════════════════════
# 9. INTERACTIVE CHAT LOOP
# ═══════════════════════════════════════════════════════════

def chat_loop():
    print("\n" + "=" * 60)
    print("  🤖  ReAct Agent  |  Groq + Llama 3.3 + FAISS Memory")
    print("  Tools : web_search, calculator")
    print("  Memory: short-term (5 turns) + long-term (FAISS)")
    print("  Type 'exit' to quit | 'clear' to wipe short-term memory")
    print("=" * 60 + "\n")

    short_term = ShortTermMemory(max_turns=5)
    long_term  = LongTermMemory(top_k=3)
    long_term.load()                                # load persisted memories

    while True:
        user_input = input("You: ").strip()
        if not user_input:
            continue
        if user_input.lower() in ("exit", "quit", "q"):
            print("Goodbye! 👋")
            break
        if user_input.lower() == "clear":
            short_term.clear()
            print("  🗑  Short-term memory cleared.\n")
            continue

        answer = ask(user_input, short_term, long_term)
        print(f"\nAgent: {answer}\n")

# ═══════════════════════════════════════════════════════════
# 10. ENTRY POINT
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":

    # --- Demo: two questions to show memory in action ---
    print("\n[Demo] Memory demonstration:\n")

    short_mem = ShortTermMemory(max_turns=5)
    long_mem  = LongTermMemory(top_k=3)
    long_mem.load()

    # First question
    a1 = ask("What is the current population of India and what is 1.4 billion divided by 1.3 million?", short_mem, long_mem)
    print(f"\n✅ Answer 1:\n{a1}\n")

    # Second question — agent will recall the first answer from short-term memory
    a2 = ask("Based on what we just discussed, what is 10% of India's population?", short_mem, long_mem)
    print(f"\n✅ Answer 2:\n{a2}\n")

    # --- Uncomment for interactive multi-turn chat ---
    # chat_loop()
