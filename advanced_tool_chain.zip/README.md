```
╔══════════════════════════════════════════════════════════════════════════════╗
║   ADVANCED TOOL-CHAINING MULTI-AGENT SYSTEM — LangGraph + Groq             ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

## 🏗️ Architecture

```
🧭 Agent 1 — Query Router       [SEQUENTIAL]   Tool: LLM Parser
        │
        │  ── 3-way parallel fan-out ──────────────────────────────────────
        ▼                       ▼                          ▼
📰 Agent 2 — News          📈 Agent 3 — Finance+SQL   🌦️ Agent 4 — Weather
   [PARALLEL]                 [PARALLEL]                  [PARALLEL]
   ① Google RSS               ① yFinance API              ① Geocoding API
       ↓ chain                    ↓ chain                      ↓ chain
   ② DuckDuckGo               ② SQLite Write               ② Weather Forecast
        │                         │                              │
        └─────────────────────────┴──────────────────────────────┘
                                  │ fan-in (all 3 done)
                                  ▼
🗄️ Agent 5 — SQL Intelligence  [SEQUENTIAL]   Tool: SQLite Read (3 queries)
        │  ← chains Agent 3 DB
        ▼
🧠 Agent 6 — Master Synthesiser [SEQUENTIAL]  Tool: Wikipedia + LLM
```

## 🔗 Tool Chain Map

| # | Tool | Called By | Chains Into |
|---|------|-----------|-------------|
| 1 | LLM Query Parser | Agent 1 | All agents (entities) |
| 2 | Google News RSS | Agent 2 | DuckDuckGo (top headline) |
| 3 | DuckDuckGo | Agent 2 | News brief synthesis |
| 4 | Yahoo Finance API | Agent 3 | SQLite Write |
| 5 | SQLite Write | Agent 3 | SQLite Read (Agent 5) |
| 6 | Geocoding API | Agent 4 | Weather Forecast API |
| 7 | Weather Forecast | Agent 4 | Business impact LLM |
| 8 | SQLite Read | Agent 5 | Final report (Agent 6) |
| 9 | Wikipedia | Agent 6 | Final report |

## ⚙️ Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Create .env file
echo "GROQ_API_KEY=gsk_your_key_here" > .env

# 3. Run
streamlit run advanced_tool_chain.py
```

## 🔑 API Keys

| Service | Key Required | Get it at |
|---------|-------------|-----------|
| Groq LLM | ✅ Required | console.groq.com (FREE) |
| Google RSS | ❌ None | Built-in |
| DuckDuckGo | ❌ None | Built-in |
| yFinance | ❌ None | pip install yfinance |
| Open-Meteo | ❌ None | Built-in |
| Wikipedia | ❌ None | Built-in |
| SQLite | ❌ None | Built-in stdlib |

## 💾 Database

A `intelligence.db` SQLite file is created automatically in the project folder.

Table: `financial_snapshots`
```sql
CREATE TABLE financial_snapshots (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    run_ts      TEXT,
    company     TEXT,
    ticker      TEXT,
    price       REAL,
    currency    TEXT,
    market_cap  REAL,
    pe_ratio    REAL,
    week52_high REAL,
    week52_low  REAL,
    volume      INTEGER,
    avg_volume  INTEGER,
    sector      TEXT,
    industry    TEXT,
    employees   INTEGER,
    source      TEXT
);
```

## 📝 Example Queries

- `Analyse Tesla and the weather in Austin Texas`
- `Research Apple Inc stock and latest news`
- `Tell me about Infosys and weather in Bangalore`
- `Analyse Reliance Industries, Mumbai`
- `Research NVIDIA recent developments`

## 🧠 Key LangGraph Concepts

**Parallel fan-out:**  
Multiple edges from one node → LangGraph runs them concurrently.

**Parallel fan-in:**  
Multiple edges pointing to the same node → LangGraph waits for ALL to complete.

**Annotated accumulator:**  
`parallel_outputs: Annotated[list[str], operator.add]` allows parallel agents
to safely append without overwriting each other.

**Critical rule:**  
Parallel nodes must return ONLY their own keys — never spread the full state
with `**state` in a parallel node.
